<?php $__env->startSection('content'); ?>
<h1 class="h4 mb-3">Leads</h1>
<div class="card">
    <div class="table-responsive">
        <table id="myTable" class="table table-striped mb-0">
            <thead>
            <tr>
                <th>Nama</th>
                <th>Email</th>
                <th>Telepon</th>
                <th>Alamat</th>
                <th>Dibuat</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($lead->name); ?></td>
                    <td><?php echo e($lead->email); ?></td>
                    <td><?php echo e($lead->phone); ?></td>
                    <td><?php echo e($lead->address); ?></td>
                    <td><?php echo e($lead->created_at?->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">Belum ada data lead.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Apps\smart_crm\resources\views/leads/index.blade.php ENDPATH**/ ?>