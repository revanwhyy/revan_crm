<?php $__env->startSection('content'); ?>
<h1 class="h4 mb-3">Projects</h1>
<div class="card">
    <div class="table-responsive">
        <table id="myTable" class="table table-striped mb-0 align-middle">
            <thead>
            <tr>
                <th>#</th>
                <th>Lead</th>
                <th>Produk</th>
                <th>Sales</th>
                <th>Status</th>
                <th class="text-end no-sort">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($project->id); ?></td>
                    <td>
                        <div class="fw-semibold"><?php echo e($project->lead->name); ?></div>
                        <div class="small text-muted"><?php echo e($project->lead->email); ?> | <?php echo e($project->lead->phone); ?></div>
                        <div class="small text-muted"><?php echo e($project->lead->address); ?></div>
                    </td>
                    <td>
                        <div class="fw-semibold"><?php echo e($project->product->name); ?></div>
                        <div class="small text-muted">Rp <?php echo e(number_format($project->product->subtotal, 0, ',', '.')); ?></div>
                    </td>
                    <td><?php echo e($project->user?->name ?? '-'); ?></td>
                    <td>
                        <?php ($badge = match($project->status){
                            'waiting' => 'secondary',
                            'in_progress' => 'info',
                            'waiting_for_approval' => 'warning',
                            'approved' => 'success',
                            'rejected' => 'danger',
                            default => 'secondary'
                        }); ?>
                        <span class="badge bg-<?php echo e($badge); ?> text-uppercase"><?php echo e(str_replace('_',' ', $project->status)); ?></span>
                    </td>
                    <td class="text-end">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->isManager()): ?>
                                <?php if($project->status === \App\Models\Project::STATUS_WAITING): ?>
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#assignModal<?php echo e($project->id); ?>">Assign</button>
                                <?php endif; ?>
                                <?php if($project->status === \App\Models\Project::STATUS_WAITING_FOR_APPROVAL): ?>
                                    <form method="POST" action="<?php echo e(route('projects.updateStatus', $project)); ?>" class="d-inline" onsubmit="return confirm('Setujui project ini?')">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="approved">
                                        <button class="btn btn-sm btn-success">Approve</button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('projects.updateStatus', $project)); ?>" class="d-inline" onsubmit="return confirm('Tolak project ini?')">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="rejected">
                                        <button class="btn btn-sm btn-danger">Reject</button>
                                    </form>
                                <?php endif; ?>
                            <?php elseif(auth()->user()->isSales()): ?>
                                <?php if($project->status === \App\Models\Project::STATUS_IN_PROGRESS && $project->user_id === auth()->id()): ?>
                                    <form method="POST" action="<?php echo e(route('projects.updateStatus', $project)); ?>" class="d-inline" onsubmit="return confirm('Ubah status ke menunggu persetujuan?')">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="waiting_for_approval">
                                        <button class="btn btn-sm btn-warning">Ajukan Persetujuan</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>

                <?php if(auth()->check() && auth()->user()->isManager()): ?>
                <?php $__env->startPush('modals'); ?>
                <div class="modal fade" id="assignModal<?php echo e($project->id); ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Assign Sales - Project #<?php echo e($project->id); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form method="POST" action="<?php echo e(route('projects.assign', $project)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label class="form-label">Pilih Sales</label>
                                        <select name="user_id" class="form-select" required>
                                            <option value="" disabled selected>-- Pilih --</option>
                                            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($s->id); ?>" <?php if($project->user_id === $s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?> (<?php echo e($s->email); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php $__env->stopPush(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">Belum ada project.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Apps\smart_crm\resources\views/projects/index.blade.php ENDPATH**/ ?>