<?php $__env->startSection('content'); ?>
<h1 class="h4 mb-3">Customers (Approved Projects)</h1>
<div class="card">
    <div class="table-responsive">
        <table id="myTable" class="table table-striped mb-0 align-middle">
            <thead>
            <tr>
                <th>#</th>
                <th>Lead</th>
                <th>Produk</th>
                <th>Sales</th>
                <th>Disetujui Pada</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($project->id); ?></td>
                    <td>
                        <div class="fw-semibold"><?php echo e($project->lead->name); ?></div>
                        <div class="small text-muted"><?php echo e($project->lead->email); ?> | <?php echo e($project->lead->phone); ?></div>
                        <div class="small text-muted"><?php echo e($project->lead->address); ?></div>
                    </td>
                    <td>
                        <div class="fw-semibold"><?php echo e($project->product->name); ?></div>
                        <div class="small text-muted">Rp <?php echo e(number_format($project->product->subtotal, 0, ',', '.')); ?></div>
                    </td>
                    <td><?php echo e($project->user?->name ?? '-'); ?></td>
                    <td><?php echo e($project->updated_at?->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">Belum ada pelanggan (approved).</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Apps\revan_crm\resources\views/customers/index.blade.php ENDPATH**/ ?>