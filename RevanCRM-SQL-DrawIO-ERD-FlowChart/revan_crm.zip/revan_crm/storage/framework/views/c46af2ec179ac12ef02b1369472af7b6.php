<?php $__env->startSection('content'); ?>
<h1 class="h4 mb-3">Tambah Produk</h1>
<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('products.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Deskripsi</label>
                <textarea name="description" class="form-control" rows="4"><?php echo e(old('description')); ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Harga (Rp)</label>
                <input type="number" name="subtotal" class="form-control" value="<?php echo e(old('subtotal')); ?>" min="0" step="0.01" required>
            </div>
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Batal</a>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Apps\smart_crm\resources\views/products/create.blade.php ENDPATH**/ ?>