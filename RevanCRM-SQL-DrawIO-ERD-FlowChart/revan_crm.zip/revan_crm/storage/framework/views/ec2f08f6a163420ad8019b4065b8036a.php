<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4 mb-0">Produk</h1>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">Tambah Produk</a>
</div>

<div class="card">
    <div class="table-responsive">
        <table id="myTable" class="table table-striped mb-0">
            <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Harga</th>
                <th class="text-end no-sort">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td class="text-truncate" style="max-width: 400px;"><?php echo e($product->description); ?></td>
                    <td>Rp <?php echo e(number_format($product->subtotal, 0, ',', '.')); ?></td>
                    <td class="text-end">
                        <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form method="POST" action="<?php echo e(route('products.destroy', $product)); ?>" class="d-inline" onsubmit="return confirm('Hapus produk ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">Belum ada produk.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Apps\smart_crm\resources\views/products/index.blade.php ENDPATH**/ ?>